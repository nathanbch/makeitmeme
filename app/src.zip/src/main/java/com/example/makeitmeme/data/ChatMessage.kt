package com.example.makeitmeme.data

data class ChatMessage(
    val sender: String = "",
    val text: String = ""
)